/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Ikbal Ahmed
 */

   import javax.swing.JTable;
import java.awt.*;
import java.awt.print.*; 
public class TablePrintable implements Printable {
    private JTable table;
    
    public TablePrintable(JTable table) {
        this.table = table;
    }

    @Override
    public int print(Graphics graphics, PageFormat pageFormat, int pageIndex) throws PrinterException {
        // Implement the print method to draw the table content on the printable area
        // You'll need to calculate how many pages are needed to print the entire table
        // and draw the relevant portion on each page.
        return Printable.NO_SUCH_PAGE;
    }
}
    
